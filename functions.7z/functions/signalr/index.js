const appInsights = require("applicationinsights");
appInsights.setup();
const client = appInsights.defaultClient;

module.exports = async function (context, _req, connectionInfo) {
    context.log('JavaScript HTTP trigger signalr function processed a request.');
    context.res = { body: connectionInfo };
    context.done();
    client.trackDependency({ target: "http://dbname", name: "signalr-function", data: "connection info", duration: 231, resultCode: 0, success: true, dependencyTypeName: "ZSQL", tagOverrides: operationIdOverride });
}